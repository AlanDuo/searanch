create definer = root@localhost event event_update_weight on schedule
    every '1' HOUR
        starts '2020-03-22 22:21:37'
    on completion preserve
    enable
    do
    CALL update_weight();

