create
    definer = root@localhost procedure update_weight()
BEGIN
		UPDATE browse set weight=weight-1 where to_days(now())-to_days(browse_time)>1;
	end;

